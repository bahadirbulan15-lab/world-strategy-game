# World Command – tarayıcı strateji oyunu prototipi

Bu proje, Age of Conflicts tarzı bir dünya strateji oyununun ilk web prototipidir.

## İçerik
- Tarayıcı arayüzü ve etkileşimli dünya haritası
- Herkese açık ve şifreli özel odalar
- Oda sahibinin belirlediği oyuncu kapasitesi (2–100)
- Oyuncuların haritadan ülke seçmesi
- Eş zamanlı tur mantığı ve turu oda yöneticisinin bitirmesi
- Oda sohbeti
- Basit hazine ve tur geliri gösterimi

## Yerel çalıştırma
1. Bilgisayarına Node.js 20 veya üzerini kur.
2. Bu klasörde terminal aç.
3. `npm install` komutunu çalıştır.
4. `npm start` komutunu çalıştır.
5. Tarayıcıda `http://localhost:3000` adresini aç.

Aynı ağdaki başka cihazlar, sunucu bilgisayarının yerel IP adresi ve `:3000` portu üzerinden bağlanabilir (güvenlik duvarı izin vermelidir).

## Herkesin internetten açabilmesi
Bu proje Node.js sunucusu gerektirir. İnternette herkese açık olması için projeyi Render, Railway, Fly.io veya başka bir Node.js barındırma servisine dağıtmalısın. `render.yaml` Render dağıtım ayarını içerir.

Render örneği:
1. ZIP'i aç ve dosyaları bir GitHub deposuna yükle.
2. Render hesabında **New + → Blueprint** seçip depoyu bağla.
3. `render.yaml` ayarlarını kullanarak servisi oluştur.
4. Dağıtım tamamlanınca verilen `https://...` adresini herkes açabilir.

Barındırma servisinin ücretsiz planları değişebilir; bazıları uykuya geçebilir veya kullanım sınırı koyabilir.

## Önemli prototip sınırları
- Oda ve oyun verileri şu an sunucunun belleğinde tutulur. Sunucu yeniden başlarsa odalar silinir.
- Kalıcı hesaplar, parola sıfırlama, veritabanı, gelişmiş admin rolleri ve güvenlik denetimi henüz eklenmemiştir.
- Savaş, diplomasi, ittifak, şehir nüfusu, bölgesel fetih, kayıt/yükleme ve gelişmiş ekonomi henüz tam oyun mekaniği olarak uygulanmamıştır.
- Gerçek oyunculara açmadan önce kimlik doğrulama, oda şifresi güvenliği, oran sınırlama, moderasyon ve kalıcı veritabanı eklenmelidir.
- Harita kütüphanesi ve harita verisi CDN üzerinden yüklenir; internet bağlantısı gerekir.

Bu, internete dağıtılabilir bir başlangıç prototipidir; henüz tamamlanmış, üretim kalitesinde bir oyun değildir.
