const socket = io();
const $ = id => document.getElementById(id);
let currentRoom = null, state = null, selectedCountry = null, map = null, geoLayer = null, geoData = null;

socket.on("connect", () => $("connection").textContent = "Sunucu bağlantısı aktif");
socket.on("disconnect", () => $("connection").textContent = "Bağlantı kesildi");
socket.on("rooms", renderRooms);
socket.on("roomState", data => { state = data; renderState(); });

function error(message) { $("lobbyError").textContent = message || ""; }
function emitAck(event, data) {
  return new Promise(resolve => socket.emit(event, data, resolve));
}
$("privateRoom").addEventListener("change", () => $("passwordWrap").classList.toggle("hidden", !$("privateRoom").checked));
$("createBtn").onclick = async () => {
  error("");
  const result = await emitAck("createRoom", {
    name: $("roomName").value, playerName: $("createName").value,
    maxPlayers: $("maxPlayers").value, isPrivate: $("privateRoom").checked,
    password: $("createPassword").value
  });
  if (!result?.ok) return error(result?.error || "Oda oluşturulamadı.");
  currentRoom = result.roomId; showGame();
};
$("joinBtn").onclick = joinTypedRoom;
$("roomCode").addEventListener("keydown", e => { if (e.key === "Enter") joinTypedRoom(); });
async function joinTypedRoom() {
  error("");
  const result = await emitAck("joinRoom", {
    roomId: $("roomCode").value, playerName: $("joinName").value,
    password: $("joinPassword").value
  });
  if (!result?.ok) return error(result?.error || "Odaya katılınamadı.");
  currentRoom = $("roomCode").value.trim().toUpperCase(); showGame();
}
$("refreshBtn").onclick = () => socket.emit("requestRooms");
function renderRooms(rooms) {
  const host = $("roomList");
  if (!rooms?.length) { host.innerHTML = '<p class="muted">Şu anda açık oda yok. İlk odayı sen oluştur.</p>'; return; }
  host.innerHTML = "";
  rooms.forEach(room => {
    const row = document.createElement("div"); row.className = "room-row";
    const info = document.createElement("div");
    const title = document.createElement("strong"); title.textContent = room.name;
    const detail = document.createElement("small"); detail.textContent = `${room.players}/${room.maxPlayers} oyuncu • Kod: ${room.id}`;
    info.append(title, detail);
    const btn = document.createElement("button"); btn.textContent = "Katıl";
    btn.onclick = async () => {
      const result = await emitAck("joinRoom", { roomId: room.id, playerName: $("joinName").value || $("createName").value });
      if (!result?.ok) return error(result?.error || "Katılınamadı.");
      currentRoom = room.id; showGame();
    };
    row.append(info, btn); host.append(row);
  });
}
function showGame() {
  $("lobby").classList.add("hidden"); $("game").classList.remove("hidden");
  $("roomCodeLabel").textContent = `Oda kodu: ${currentRoom}`;
  if (!map) initMap();
}
function initMap() {
  map = L.map("map", { worldCopyJump: true }).setView([22, 8], 2);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png", {
    attribution: '&copy; OpenStreetMap &copy; CARTO', maxZoom: 8
  }).addTo(map);
  fetch("https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson")
    .then(r => { if (!r.ok) throw new Error("Harita verisi yüklenemedi"); return r.json(); })
    .then(data => { geoData = data; drawCountries(); })
    .catch(() => $("countryInfo").textContent = "Harita verisi yüklenemedi. İnternet bağlantını kontrol et.");
}
function countryName(feature) {
  const p = feature.properties || {};
  return p.ADMIN || p.name || p.NAME || p.name_long || "Bilinmeyen ülke";
}
function drawCountries() {
  if (geoLayer) map.removeLayer(geoLayer);
  geoLayer = L.geoJSON(geoData, {
    style: feature => {
      const name = countryName(feature), owner = state?.countries?.[name];
      return { color: "#60758b", weight: .7, fillColor: owner ? owner.color : "#36536c", fillOpacity: owner ? .9 : .62 };
    },
    onEachFeature: (feature, layer) => layer.on("click", () => selectCountry(countryName(feature)))
  }).addTo(map);
}
function selectCountry(name) {
  selectedCountry = name; $("selectedLabel").textContent = name;
  const owned = state?.countries?.[name];
  const me = state?.players?.find(p => p.id === socket.id);
  $("countryInfo").textContent = owned ? `${name} • ${owned.ownerId === socket.id ? "Senin ülken" : "Başka oyuncunun ülkesi"}` : `${name} henüz seçilmedi.`;
  $("claimBtn").disabled = !!owned && owned.ownerId !== socket.id;
  $("claimBtn").textContent = owned?.ownerId === socket.id ? "Ülken seçildi" : "Bu ülkeyi seç";
  $("treasury").textContent = me?.country === name ? me.treasury.toLocaleString("tr-TR") : "—";
  $("income").textContent = me?.country === name ? me.income.toLocaleString("tr-TR") : "—";
}
$("claimBtn").onclick = async () => {
  if (!selectedCountry) return;
  const result = await emitAck("claimCountry", selectedCountry);
  if (!result?.ok) $("countryInfo").textContent = result?.error || "Ülke seçilemedi.";
};
$("endTurnBtn").onclick = async () => {
  const result = await emitAck("endTurn");
  if (!result?.ok) alert(result?.error || "Tur bitirilemedi.");
};
$("leaveBtn").onclick = () => { location.reload(); };
$("chatForm").onsubmit = async e => {
  e.preventDefault(); const value = $("chatInput").value.trim(); if (!value) return;
  const result = await emitAck("sendMessage", value);
  if (result?.ok) $("chatInput").value = "";
};
function renderState() {
  if (!state) return;
  $("gameRoomName").textContent = state.name;
  $("roundNumber").textContent = state.round;
  $("playerCount").textContent = `${state.players.length}/${state.maxPlayers}`;
  const me = state.players.find(p => p.id === socket.id);
  const isHost = state.hostId === socket.id;
  $("endTurnBtn").disabled = !isHost;
  $("adminNote").textContent = isHost ? "Oda yöneticisisin. Hazır olduğunda turu bitirebilirsin." : "Turu yalnızca oda yöneticisi bitirebilir.";
  $("players").innerHTML = "";
  state.players.forEach(p => {
    const row = document.createElement("div"); row.className = "player";
    const left = document.createElement("span"); left.textContent = `${p.name}${p.id === state.hostId ? " ★" : ""}`;
    const right = document.createElement("small"); right.textContent = p.country || "Ülke seçmedi";
    row.append(left, right); $("players").append(row);
  });
  $("chatLog").innerHTML = "";
  state.log.slice(-25).forEach(item => {
    const line = document.createElement("div"); line.className = "chat-line"; line.textContent = item.message;
    $("chatLog").append(line);
  });
  $("chatLog").scrollTop = $("chatLog").scrollHeight;
  if (me?.country) selectCountry(me.country);
  if (geoData) drawCountries();
}
