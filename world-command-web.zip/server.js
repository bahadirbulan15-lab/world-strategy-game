const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

const rooms = new Map();
const clean = (v, max = 24) => String(v || "").trim().replace(/[<>]/g, "").slice(0, max);
const publicRoom = room => ({
  id: room.id, name: room.name, isPrivate: room.isPrivate,
  players: room.players.size, maxPlayers: room.maxPlayers
});
function snapshot(room) {
  return {
    id: room.id, name: room.name, round: room.round,
    hostId: room.hostId, maxPlayers: room.maxPlayers,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, country: p.country, ready: p.ready,
      treasury: p.treasury, income: p.income
    })),
    countries: room.countries,
    log: room.log.slice(-30)
  };
}
function broadcastRoom(room) {
  io.to(room.id).emit("roomState", snapshot(room));
  io.emit("rooms", [...rooms.values()].filter(r => !r.isPrivate).map(publicRoom));
}
function addLog(room, message) {
  room.log.push({ at: Date.now(), message });
  room.log = room.log.slice(-60);
}
function leaveRoom(socket) {
  const roomId = socket.data.roomId;
  if (!roomId) return;
  const room = rooms.get(roomId);
  socket.leave(roomId);
  socket.data.roomId = null;
  if (!room) return;
  room.players.delete(socket.id);
  if (room.players.size === 0) rooms.delete(roomId);
  else {
    if (room.hostId === socket.id) {
      room.hostId = room.players.keys().next().value;
      addLog(room, "Oda yöneticisi değişti.");
    }
    broadcastRoom(room);
  }
}

io.on("connection", socket => {
  socket.emit("rooms", [...rooms.values()].filter(r => !r.isPrivate).map(publicRoom));

  socket.on("createRoom", (data, reply = () => {}) => {
    leaveRoom(socket);
    const name = clean(data.name, 24) || "Yeni Oda";
    const playerName = clean(data.playerName, 18) || "Oyuncu";
    const maxPlayers = Math.max(2, Math.min(100, Number(data.maxPlayers) || 10));
    const id = crypto.randomBytes(3).toString("hex").toUpperCase();
    const room = {
      id, name, isPrivate: !!data.isPrivate,
      password: roomPassword(data.password), maxPlayers,
      hostId: socket.id, round: 1, players: new Map(),
      countries: {}, log: []
    };
    room.players.set(socket.id, { id: socket.id, name: playerName, country: "", ready: false, treasury: 1000, income: 100 });
    rooms.set(id, room);
    socket.join(id); socket.data.roomId = id;
    addLog(room, `${playerName} odayı oluşturdu.`);
    broadcastRoom(room);
    reply({ ok: true, roomId: id });
  });

  socket.on("joinRoom", (data, reply = () => {}) => {
    leaveRoom(socket);
    const id = clean(data.roomId, 12).toUpperCase();
    const room = rooms.get(id);
    if (!room) return reply({ ok: false, error: "Oda bulunamadı." });
    if (room.players.size >= room.maxPlayers) return reply({ ok: false, error: "Oda dolu." });
    if (room.isPrivate && room.password !== roomPassword(data.password)) return reply({ ok: false, error: "Şifre yanlış." });
    const playerName = clean(data.playerName, 18) || "Oyuncu";
    room.players.set(socket.id, { id: socket.id, name: playerName, country: "", ready: false, treasury: 1000, income: 100 });
    socket.join(id); socket.data.roomId = id;
    addLog(room, `${playerName} odaya katıldı.`);
    broadcastRoom(room);
    reply({ ok: true });
  });

  socket.on("claimCountry", (countryName, reply = () => {}) => {
    const room = rooms.get(socket.data.roomId);
    if (!room) return reply({ ok: false, error: "Önce bir odaya katıl." });
    const player = room.players.get(socket.id);
    const country = clean(countryName, 80);
    if (!country) return reply({ ok: false, error: "Ülke adı geçersiz." });
    const occupied = Object.values(room.countries).some(c => c.ownerId !== socket.id && c.name === country);
    if (occupied) return reply({ ok: false, error: "Bu ülke başka bir oyuncuda." });
    if (player.country) delete room.countries[player.country];
    player.country = country;
    room.countries[country] = { name: country, ownerId: socket.id, color: "#d6a83b", treasury: player.treasury };
    addLog(room, `${player.name}, ${country} ülkesini seçti.`);
    broadcastRoom(room); reply({ ok: true });
  });

  socket.on("setReady", (ready, reply = () => {}) => {
    const room = rooms.get(socket.data.roomId);
    if (!room) return reply({ ok: false });
    room.players.get(socket.id).ready = !!ready;
    broadcastRoom(room); reply({ ok: true });
  });

  socket.on("endTurn", (_data, reply = () => {}) => {
    const room = rooms.get(socket.data.roomId);
    if (!room || room.hostId !== socket.id) return reply({ ok: false, error: "Bu işlem yalnızca oda yöneticisine açık." });
    room.round += 1;
    for (const p of room.players.values()) {
      p.treasury += p.income;
      p.ready = false;
    }
    addLog(room, `Yönetici turu bitirdi. ${room.round}. tur başladı; gelirler toplandı.`);
    broadcastRoom(room); reply({ ok: true });
  });

  socket.on("sendMessage", (message, reply = () => {}) => {
    const room = rooms.get(socket.data.roomId);
    if (!room) return reply({ ok: false });
    const player = room.players.get(socket.id);
    const text = clean(message, 240);
    if (!text) return reply({ ok: false });
    addLog(room, `${player.name}: ${text}`);
    broadcastRoom(room); reply({ ok: true });
  });

  socket.on("disconnect", () => leaveRoom(socket));
});

function roomPassword(value) {
  return value ? crypto.createHash("sha256").update(String(value).slice(0, 64)).digest("hex") : "";
}

server.listen(PORT, () => console.log(`Game server listening on ${PORT}`));
